import sparadrap.models.*;
import sparadrap.services.SparadrapCREATE;

import java.sql.Date;
import java.time.LocalDateTime;

public class SparadrapJava
{
    public static void main( String[] args ) throws Exception {
        newSpecialite();
    }

    private static void newAchat() {

    }

    private static void newClient() {

    }

    private static void newCoordonne() {

    }

    private static void newMedecin() {

    }

    private static void newMedicament() {

    }

    private static void newMutuelle() {

    }

    private static void newOrdonance() {

    }

    private static void newPersonne() {

    }

    private static void newSpecialite() throws Exception {
        Specialite specialite = new Specialite();
        specialite.setLibelle("new");
        SparadrapCREATE.creerSpecialite(specialite);
    }
}