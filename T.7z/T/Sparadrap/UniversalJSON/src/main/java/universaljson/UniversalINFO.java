package universaljson;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.tuple.Pair;
import universaljson.enums.UniversalSQL;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
/**
 * [A] - class
 * @author Mathaus
 */
public class UniversalINFO {
	private final Map<String, UniversalSQL> info = new HashMap<>();
	public UniversalINFO(Class<?> clazz) {
//		while (clazz != null && !clazz.getSuperclass().equals(UniversalJSON.class)) {
//			clazz = clazz.getSuperclass();
//		}
		for (Field field : clazz.getDeclaredFields()) {
			JsonProperty annotation = field.getAnnotation(JsonProperty.class);
			if (annotation != null) {
				info.put(annotation.value().toUpperCase(), UniversalSQL.reverseConvert(field.getType()));
			}
		}
//		while (clazz != null) {
//			// Parcours des champs de la classe courante
//
//			// Passe à la classe parente
//			clazz = clazz.getSuperclass();
//		}

	}
	public final boolean contains(String key) {
		return info.containsKey(key.toUpperCase());
	}
	public Pair<String, UniversalSQL> getAuthorizedKey(String key) {
		UniversalSQL auth = info.get(key.toUpperCase());
		if (auth == null) return null;
		return Pair.of(key.toUpperCase(), auth);
	}
}