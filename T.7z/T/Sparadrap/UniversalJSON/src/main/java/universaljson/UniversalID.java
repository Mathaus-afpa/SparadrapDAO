package universaljson;
public interface UniversalID {
    Integer getId();
}