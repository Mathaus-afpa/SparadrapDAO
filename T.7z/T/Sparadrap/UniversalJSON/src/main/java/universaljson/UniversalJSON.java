package universaljson;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.apache.commons.lang3.tuple.Pair;
import org.json.JSONObject;
import universaljson.enums.UniversalSQL;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * [UniJSON] - class
 * @author Mathaus
 */
public class UniversalJSON {
	//<editor-fold defaultstate="expanded" desc="STATIC">
	//START________________________________________________[static]___________________________________________________//
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Proprietes PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Fonctions PUBLIC">
//	public static boolean getKeys(Class<?> clazz, String test) {
//		UniversalINFO hey = instanciedMap.get(clazz);
//		return hey.getInfo().containsKey(test.toUpperCase());
//	}
	public UniversalINFO getUniversalINFO() {
		return instanciedMap.get(this.getClass());
	}
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Proprietes PRIVATE">
	private static final Map<Class<?>, UniversalINFO> instanciedMap = new HashMap<>();
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Fonctions PRIVATE">
	private static void newClassInfo(Class<?> clazz) {
		instanciedMap.computeIfAbsent(clazz, classInfo -> new UniversalINFO(clazz));
	}
    //</editor-fold>
	//</editor-fold>
    //END//////////////////////////////////////////////////[static]/////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="INSTANCE">
    //START_______________________________________________[instance]__________________________________________________//
    //<editor-fold defaultstate="expanded" desc="SINGLETON">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="CONSTRUCTEURS">
	public UniversalJSON() {
		Class<?> clazz = this.getClass();
		while (clazz != null && !clazz.equals(UniversalJSON.class)) {
			UniversalJSON.newClassInfo(clazz);
			clazz = clazz.getSuperclass();
		}
		//UniversalJSON.newClassInfo(clazz);
	}
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Attributs PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Methodes PUBLIC">
	public void updateValue(String key, Object value) {

		Class<?> clazz = this.getClass();
		UniversalJSON json = this;
		while (clazz != null && !clazz.equals(UniversalJSON.class)) {
			UniversalINFO info = instanciedMap.get(clazz);
			if (this.getClass() == clazz) {
				if (info.contains(key)) {
					Pair<String, UniversalSQL> kt = info.getAuthorizedKey(key);
					if (kt != null) {
						System.out.println("updata value:: " + key);
						json.values.put(key, UniversalSQL.convert(kt.getRight(), value.toString()));
						if (ifNewKey(key)) {
							json.datatypes.put(key, kt.getRight());
						}
					}
				}
			}
			clazz = clazz.getSuperclass();
			json = (UniversalJSON) clazz.cast(this);
		}
//		UniversalINFO info = instanciedMap.get(this.getClass());
//		if (info.contains(key)) {
//			Pair<String, UniversalSQL> kt = info.getAuthorizedKey(key);
//			if (kt != null) {
//				System.out.println("updata value:: " + key);
//				this.values.put(key, UniversalSQL.convert(kt.getRight(), value.toString()));
//				if (ifNewKey(key)) {
//					this.datatypes.put(key, kt.getRight());
//				}
//			}
//		}
	//	else {
//			Class<?> parentClass = this.getClass().getSuperclass();
//			while (parentClass != null && parentClass != Object.class) {
//
//			}
//			if (parentClass != null && UniversalJSON.class.isAssignableFrom(parentClass)) {
//				UniversalJSON p = (UniversalJSON) parentClass.cast(this);
//				p.updateValue(key, value);
//				System.out.println("updata value:: " + p + " then ");
//			}

			// Si une classe parente existe, tenter d'y propager
//			if (parentClass != null && BaseClass.class.isAssignableFrom(parentClass)) {
//				try {
//					// Appeler la méthode parent en utilisant "super"
//					BaseClass parentInstance = (BaseClass) parentClass.cast(this);
//
//					p.updateValue(key, value);
//				} catch (ClassCastException e) {
//					System.out.println("Erreur de propagation vers la classe parente");
//				}
//			}
	//	}
//
//		if (kt != null) {
//			System.out.println("updata value:: " + key);
//			this.values.put(key, UniversalSQL.convert(kt.getRight(), value.toString()));
//			if (ifNewKey(key)) {
//				this.datatypes.put(key, kt.getRight());
//			}
//		} else {
//			throw new IllegalArgumentException("aaa");
//		}
	}
	public void putKey(String key, String value, UniversalSQL type) {
		if (ifNewKey(key)) {// value null ok ?
			this.values.put(key, UniversalSQL.convert(type, value));
			this.datatypes.put(key, type);
		}
	}
	public Object getValue(String key) {
		return this.values.get(key);
	}

	public Pair<String, Map<String, Object> > buildJSON() throws JsonProcessingException {
		System.out.println(this);
		JSONObject jsonObject = new JSONObject(this);
		jsonObject.remove("universalINFO");
		for (String key : jsonObject.keySet()) {
			updateValue(key, jsonObject.get(key));
		}
		Map<String, Object> filteredMap = values.entrySet().stream()
				.filter(entry ->  jsonObject.keySet().contains(entry.getKey())) // Critère de filtrage
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		System.out.println(this.getClass());
		return Pair.of(jsonObject.toString(), filteredMap);
	}
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Attributs PRIVATE">

	private boolean stringOnly = false;
	private Map<String, Object> values = new HashMap<>();
	private Map<String, UniversalSQL> datatypes = new HashMap<>();
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Methodes PRIVATE">
	private boolean ifNewKey(String key) {
		return !this.values.containsKey(key) && !this.datatypes.containsKey(key);
	}
//	private Map<String, Object> clearNull() {
//		return this.values.entrySet().stream()
//				.filter(entry -> entry.getValue() != null)
//				.collect(Collectors.toMap(
//						entry -> entry.getKey(),
//						entry -> entry.getValue()
//				));
//	}
//	private Map<String, String> formatValues() {
//		return this.values.entrySet().stream()
//				.filter(entry -> entry.getValue() != null && entry.getValue().toString() != null)
//				.collect(Collectors.toMap(
//						entry -> entry.getKey(),
//						entry -> entry.getValue().toString()
//				));
//	}
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="ENCAPSULATION">
    //<editor-fold defaultstate="expanded" desc="Getters">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Setters">
    //</editor-fold>
	//</editor-fold>
    //END/////////////////////////////////////////////////[instance]////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="OVERRIDE">
	//START_______________________________________________[override]__________________________________________________//
	//END/////////////////////////////////////////////////[override]////////////////////////////////////////////////////
	//</editor-fold>
}