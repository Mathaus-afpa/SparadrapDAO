package universaljson.utils;
import com.fasterxml.jackson.annotation.JsonProperty;
import universaljson.UniversalDATASET;
import universaljson.UniversalID;
import universaljson.UniversalJSON;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import static org.apache.commons.lang3.reflect.FieldUtils.getAllFields;

/**
 * [UniversalDebugFrame] - class
 * @author Mathaus
 */
public class UniversalDebugFrame<T extends UniversalID> extends UniversalDATASET<T> {
	//<editor-fold defaultstate="expanded" desc="STATIC">
	//START________________________________________________[static]___________________________________________________//
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Proprietes PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Fonctions PUBLIC">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Proprietes PRIVATE">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Fonctions PRIVATE">
    //</editor-fold>
	//</editor-fold>
    //END//////////////////////////////////////////////////[static]/////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="INSTANCE">
    //START_______________________________________________[instance]__________________________________________________//
    //<editor-fold defaultstate="expanded" desc="SINGLETON">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="CONSTRUCTEURS">
	public UniversalDebugFrame(List<UniversalJSON> dataset, Class<T> datatype) {
		super(dataset, datatype); // Appel du constructeur de la classe parente
		createTableView();
	}
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
	public void createTableView() {
		if (getAll().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Aucune donnée à afficher");
			return;
		}

		// On suppose ici que l'objet T contient des attributs annotés avec @JsonProperty.
		T firstData = getAll().get(0); // On prend un objet de type T pour récupérer ses attributs

		// Création de la table avec les noms des colonnes dynamiquement
		java.util.List<String> columnNames = new ArrayList<>();
		List<Object[]> rowData = new ArrayList<>();

		// On utilise la réflexion pour récupérer les champs de l'objet T et de ses superclasses
		Field[] fields = getAllFields(firstData.getClass());
		for (Field field : fields) {
			JsonProperty annotation = field.getAnnotation(JsonProperty.class);
			if (annotation != null) {  // Si le champ est annoté avec @JsonProperty
				// Ajouter le nom du champ à la liste des colonnes
				columnNames.add(annotation.value());
			}
		}

		// On prépare les lignes de données en fonction des objets dans datas
		for (T data : getAll()) {
			Object[] row = new Object[columnNames.size()];
			int columnIndex = 0;
			for (Field field : fields) {
				JsonProperty annotation = field.getAnnotation(JsonProperty.class);
				if (annotation != null) {  // Si le champ est annoté avec @JsonProperty
					field.setAccessible(true);
					try {
						// Récupérer la valeur du champ et l'ajouter à la ligne
						row[columnIndex] = field.get(data);
					} catch (IllegalAccessException e) {
						e.printStackTrace();
					}
					columnIndex++;
				}
			}
			rowData.add(row); // Ajouter la ligne dans la liste des données
		}

		// Création du modèle de la table avec les colonnes et les données
		DefaultTableModel model = new DefaultTableModel(rowData.toArray(new Object[0][]), columnNames.toArray());

		// Création de la JTable
		JTable table = new JTable(model);

		// Création de la fenêtre JFrame pour afficher la JTable
		JFrame frame = new JFrame("Table View of Object");
		//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800, 400);
		frame.setLayout(new BorderLayout());

		// Ajout de la JTable dans un JScrollPane
		JScrollPane scrollPane = new JScrollPane(table);
		frame.add(scrollPane, BorderLayout.CENTER);

		// Rendre la fenêtre visible
		frame.setVisible(true);
	}
    //<editor-fold defaultstate="expanded" desc="Attributs PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Methodes PUBLIC">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Attributs PRIVATE">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Methodes PRIVATE">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="ENCAPSULATION">
    //<editor-fold defaultstate="expanded" desc="Getters">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Setters">
    //</editor-fold>
	//</editor-fold>
    //END/////////////////////////////////////////////////[instance]////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="OVERRIDE">
	//START_______________________________________________[override]__________________________________________________//
	//END/////////////////////////////////////////////////[override]////////////////////////////////////////////////////
	//</editor-fold>
}