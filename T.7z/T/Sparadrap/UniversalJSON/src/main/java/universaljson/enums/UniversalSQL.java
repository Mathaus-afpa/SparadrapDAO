package universaljson.enums;
import universaljson.UniversalJSON;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
public enum UniversalSQL {
    TINYINT,
    SMALLINT,
    MEDIUMINT,
    INT,
    BIGINT,
    FLOAT,
    DOUBLE,
    DECIMAL,
    NUMERIC,
    BIT,
    BOOLEAN,
    CHAR,
    VARCHAR,
    TEXT,
    MEDIUMTEXT,
    LONGTEXT,
    TINYTEXT,
    ENUM,
    SET,
    BINARY,
    VARBINARY,
    BLOB,
    MEDIUMBLOB,
    LONGBLOB,
    DATE,
    DATETIME,
    TIMESTAMP,
    TIME,
    YEAR,
    JSON;
    public static <T> T convert(UniversalSQL type, String value) {
        if (type == null || value == null) return null;
        switch (type) {
            case TINYINT: return (T) Byte.valueOf(value);
            case SMALLINT: return (T) Short.valueOf(value);
            case BIGINT: return (T) Long.valueOf(value);
            case FLOAT: return (T) Float.valueOf(value);
            case DOUBLE: return (T) Double.valueOf(value);
            case DECIMAL:
            case NUMERIC: // La BDD renvoie DECIMAL et non NUMERIC
                return (T) new BigDecimal(value);
            case MEDIUMINT:
            case INT:
            case YEAR:
                return (T) Integer.valueOf(value);

            case BIT: return (T) Boolean.valueOf(value);
            case BOOLEAN: return (T) Boolean.valueOf(value); // La BDD renvoie BIT et non BOOLEAN
            case CHAR:
            case VARCHAR:
            case TEXT:
            case MEDIUMTEXT:
            case LONGTEXT:
            case TINYTEXT:
            case ENUM: // La BDD renvoie CHAR et non ENUM
            case SET: // La BDD renvoie CHAR et non SET
            case JSON:
                return (T) value;
            case BINARY:
            case VARBINARY:
            case BLOB:
            case MEDIUMBLOB:
            case LONGBLOB:
                return (T) value.getBytes();
            case DATE: return (T) Date.valueOf(value);
            case DATETIME: return (T) Timestamp.valueOf(value);
            case TIMESTAMP: return (T) Timestamp.valueOf(value);
            case TIME: return (T) Time.valueOf(value);
            default: break;
        }
        return null;
    }
    public static UniversalSQL reverseConvert(Class<?> fieldType) {
        if (fieldType == Byte.class || fieldType == byte.class) return UniversalSQL.TINYINT;
        if (fieldType == Short.class || fieldType == short.class) return UniversalSQL.SMALLINT;
        if (fieldType == Long.class || fieldType == long.class) return UniversalSQL.BIGINT;
        if (fieldType == Float.class || fieldType == float.class) return UniversalSQL.FLOAT;
        if (fieldType == Double.class || fieldType == double.class) return UniversalSQL.DOUBLE;
        if (fieldType == BigDecimal.class) return UniversalSQL.DECIMAL; // Peut être NUMERIC
        if (fieldType == Integer.class || fieldType == int.class) return UniversalSQL.INT;
        if (fieldType == Boolean.class || fieldType == boolean.class) return UniversalSQL.BOOLEAN; // Ou BIT
        if (fieldType == String.class) return UniversalSQL.VARCHAR; // Peut être TEXT, CHAR
        if (fieldType == byte[].class) return UniversalSQL.BLOB; // Peut être VARBINARY
        if (fieldType == java.sql.Date.class) return UniversalSQL.DATE;
        if (fieldType == java.sql.Timestamp.class) return UniversalSQL.TIMESTAMP; // Peut être DATETIME
        if (fieldType == java.sql.Time.class) return UniversalSQL.TIME;
        if (UniversalJSON.class.isAssignableFrom(fieldType)) return UniversalSQL.INT;
        throw new IllegalArgumentException("Type non supporté pour la conversion : " + fieldType.getName());
    }

}