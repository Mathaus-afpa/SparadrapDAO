package sparadrap.models;
import com.fasterxml.jackson.annotation.JsonProperty;
import universaljson.UniversalJSON;
import java.sql.Date;
/**
 * [Ordonance] - class
 * @author Mathaus
 */
public class Ordonance extends UniversalJSON {
	//<editor-fold defaultstate="expanded" desc="STATIC">
	//START________________________________________________[static]___________________________________________________//
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Proprietes PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Fonctions PUBLIC">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Proprietes PRIVATE">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Fonctions PRIVATE">
    //</editor-fold>
	//</editor-fold>
    //END//////////////////////////////////////////////////[static]/////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="INSTANCE">
    //START_______________________________________________[instance]__________________________________________________//
    //<editor-fold defaultstate="expanded" desc="SINGLETON">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="CONSTRUCTEURS">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Attributs PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Methodes PUBLIC">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Attributs PRIVATE">
	@JsonProperty("ID") private Integer id;
	@JsonProperty("IDMEDECIN") private Medecin idMedecin;
	@JsonProperty("IDCLIENT") private Client idClient;
	@JsonProperty("DATEPRESCRIPTION") private Date datePrescription;
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Methodes PRIVATE">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="ENCAPSULATION">
    //<editor-fold defaultstate="expanded" desc="Getters">
	public Integer getId() {
		return id;
	}
	public Medecin getIdMedecin() {
		return idMedecin;
	}
	public Client getIdClient() {
		return idClient;
	}
	public Date getDatePrescription() {
		return datePrescription;
	}
	//</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Setters">
	public void setId(Integer id) {
		this.id = id;
	}
	public void setIdMedecin(Medecin idMedecin) {
		this.idMedecin = idMedecin;
	}
	public void setIdClient(Client idClient) {
		this.idClient = idClient;
	}
	public void setDatePrescription(Date datePrescription) {
		this.datePrescription = datePrescription;
	}
	//</editor-fold>
	//</editor-fold>
    //END/////////////////////////////////////////////////[instance]////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="OVERRIDE">
	//START_______________________________________________[override]__________________________________________________//
	//END/////////////////////////////////////////////////[override]////////////////////////////////////////////////////
	//</editor-fold>
}