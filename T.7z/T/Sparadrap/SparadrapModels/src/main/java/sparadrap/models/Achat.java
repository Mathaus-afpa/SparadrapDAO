package sparadrap.models;
import com.fasterxml.jackson.annotation.JsonProperty;
import universaljson.UniversalJSON;
import java.sql.Date;
/**
 * [Achat] - class
 * @author Mathaus
 */
public class Achat extends UniversalJSON {
	//<editor-fold defaultstate="expanded" desc="STATIC">
	//START________________________________________________[static]___________________________________________________//
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Proprietes PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Fonctions PUBLIC">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Proprietes PRIVATE">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Fonctions PRIVATE">
    //</editor-fold>
	//</editor-fold>
    //END//////////////////////////////////////////////////[static]/////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="INSTANCE">
    //START_______________________________________________[instance]__________________________________________________//
    //<editor-fold defaultstate="expanded" desc="SINGLETON">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="CONSTRUCTEURS">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Attributs PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Methodes PUBLIC">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Attributs PRIVATE">
	@JsonProperty("IDACHAT") private Integer id;
	@JsonProperty("IDORDONANCE") private Ordonance idOrdonance;
	@JsonProperty("IDCLIENT") private Client idClient;
	@JsonProperty("DATEACHAT") private Date dateAchat;
	@JsonProperty("NUMEROFACTURE") private Integer numeroFacture;
	//</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Methodes PRIVATE">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="ENCAPSULATION">
    //<editor-fold defaultstate="expanded" desc="Getters">
	public Integer getId() {
		return id;
	}
	public Ordonance getIdOrdonance() {
		return idOrdonance;
	}
	public Client getIdClient() {
		return idClient;
	}
	public Date getDateAchat() {
		return dateAchat;
	}
	public Integer getNumeroFacture() {
		return numeroFacture;
	}
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Setters">
	public void setId(Integer id) {
		this.id = id;
	}
	public void setIdOrdonance(Ordonance idOrdonance) {
		this.idOrdonance = idOrdonance;
	}
	public void setIdClient(Client idClient) {
		this.idClient = idClient;
	}
	public void setDateAchat(Date dateAchat) {
		this.dateAchat = dateAchat;
	}
	public void setNumeroFacture(Integer numeroFacture) {
		this.numeroFacture = numeroFacture;
	}
	//</editor-fold>
	//</editor-fold>
    //END/////////////////////////////////////////////////[instance]////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="OVERRIDE">
	//START_______________________________________________[override]__________________________________________________//
	//END/////////////////////////////////////////////////[override]////////////////////////////////////////////////////
	//</editor-fold>
}