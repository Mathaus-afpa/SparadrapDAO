package sparadrap.models;
import com.fasterxml.jackson.annotation.JsonProperty;
import universaljson.UniversalJSON;
import java.sql.Date;
/**
 * [Medicament] - class
 * @author Mathaus
 */
public class Medicament extends UniversalJSON {
	//<editor-fold defaultstate="expanded" desc="STATIC">
	//START________________________________________________[static]___________________________________________________//
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Proprietes PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Fonctions PUBLIC">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Proprietes PRIVATE">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Fonctions PRIVATE">
    //</editor-fold>
	//</editor-fold>
    //END//////////////////////////////////////////////////[static]/////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="INSTANCE">
    //START_______________________________________________[instance]__________________________________________________//
    //<editor-fold defaultstate="expanded" desc="SINGLETON">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="CONSTRUCTEURS">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Attributs PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Methodes PUBLIC">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Attributs PRIVATE">
	@JsonProperty("IDMEDICAMENT") private Integer id;
	@JsonProperty("DATEMISEENSERVICE") private Date dateMiseEnService = new Date(System.currentTimeMillis());
	@JsonProperty("PRIX") private Float prix;
	@JsonProperty("LIBELLE") private String libelle;
	@JsonProperty("STOCK") private Integer stock;
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Methodes PRIVATE">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="ENCAPSULATION">
    //<editor-fold defaultstate="expanded" desc="Getters">
	public Integer getId() {
		return id;
	}
	public Date getDateMiseEnService() {
		return dateMiseEnService;
	}
	public Float getPrix() {
		return prix;
	}
	public String getLibelle() {
		return libelle;
	}
	public Integer getStock() {
		return stock;
	}
	//</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Setters">
	public void setId(Integer id) {
		this.id = id;
	}
	public void setDateMiseEnService(Date dateMiseEnService) {
		this.dateMiseEnService = dateMiseEnService;
	}
	public void setPrix(Float prix) {
		this.prix = prix;
	}
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	public void setStock(Integer stock) {
		this.stock = stock;
	}
	//</editor-fold>
	//</editor-fold>
    //END/////////////////////////////////////////////////[instance]////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="OVERRIDE">
	//START_______________________________________________[override]__________________________________________________//
	//END/////////////////////////////////////////////////[override]////////////////////////////////////////////////////
	//</editor-fold>
}