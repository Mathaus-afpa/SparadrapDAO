package sparadrap.models;
import com.fasterxml.jackson.annotation.JsonProperty;
import universaljson.UniversalJSON;
/**
 * [Specialite] - class
 * @author Mathaus
 */
public class Specialite extends UniversalJSON {
	@JsonProperty("IDSPECIALITE") private Integer id;
	@JsonProperty("LIBELLE") private String libelle;
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Methodes PRIVATE">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="ENCAPSULATION">
    //<editor-fold defaultstate="expanded" desc="Getters">
	public Integer getId() {
		return id;
	}
	public String getLibelle() {
		return libelle;
	}
	//</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Setters">
	public void setId(Integer id) {
		this.id = id;
	}
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	//</editor-fold>
	//</editor-fold>
    //END/////////////////////////////////////////////////[instance]////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="OVERRIDE">
	//START_______________________________________________[override]__________________________________________________//
	//END/////////////////////////////////////////////////[override]////////////////////////////////////////////////////
	//</editor-fold>
}