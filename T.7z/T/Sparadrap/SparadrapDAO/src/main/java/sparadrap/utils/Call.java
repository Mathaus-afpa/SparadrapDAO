package sparadrap.utils;
import org.json.JSONObject;
import sparadrap.enums.SparadrapTable;

/**
 * [Call] - class
 * @author Mathaus
 */
public class Call {
	//<editor-fold defaultstate="expanded" desc="STATIC">
	//START________________________________________________[static]___________________________________________________//
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Proprietes PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Fonctions PUBLIC">
	public static final String getDeleteStatement(SparadrapTable table) {
		clearStringBuilder();
		sqlBuilder.append("DELETE FROM ");
		sqlBuilder.append(table);
		sqlBuilder.append(" WHERE ID");
		sqlBuilder.append(table);
		sqlBuilder.append(" = ?");
		return buildAndClear();
	}
	public static final String getSelectStatement(SparadrapTable table) {
		switch (table) {
			case ACHAT: return "SELECT * FROM achat";
			case CLIENT: return "SELECT e.identite, e.nom, e.adresse, e.telephone, e.email, e.codePostal, p.idPersonne, p.prenom, c.idClient, c.dateDeNaissance, c.numeroSecuriteSociale, c.idMutuelle FROM entite e JOIN personne p ON e.identite = p.identite JOIN client c ON p.idPersonne = c.idPersonne";
			case MEDECIN: return "SELECT e.identite, e.nom, e.adresse, e.telephone, e.email, e.codePostal, p.idPersonne, p.prenom, m.idMedecin, m.agreement FROM entite e JOIN personne p ON e.identite = p.identite JOIN medecin m ON p.idPersonne = m.idPersonne";
			case MEDICAMENT: return "SELECT * FROM medicaments";
			case MUTUELLE: return "SELECT e.identite, e.nom, e.adresse, e.telephone, e.email, e.codePostal, m.idMutuelle, m.tauxRemboursement FROM entite e JOIN mutuelle m ON m.identite = e.identite";
			case ORDONANCE: return "SELECT * FROM ordonance";
			case SPECIALITE: return "SELECT * FROM specialite";
			default: return "SELECT * FROM "  + table;
		}
    }
	public static final String getUpdateStatement(SparadrapTable table, String jsonString) {
		clearStringBuilder();
		String sql = "UPDATE users SET email = ? WHERE id = ?";
		sqlBuilder.append(table.toString());
		return generateInsertQuery(jsonString);
	}
	public static final String getInsertStatement(SparadrapTable table, StringBuilder columns, StringBuilder values) {
		clearStringBuilder();
		sqlBuilder.append("INSERT INTO ");
		sqlBuilder.append(table.toString());
		sqlBuilder.append(columns.toString());
		sqlBuilder.append(values.toString());
		return buildAndClear();
	}
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Proprietes PRIVATE">
	private static StringBuilder sqlBuilder = new StringBuilder();
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Fonctions PRIVATE">
	private static void clearStringBuilder() {
		sqlBuilder.delete(0, sqlBuilder.length());
		sqlBuilder.setLength(0);
	}
	private static String buildAndClear() {
		String result = sqlBuilder.toString();
		clearStringBuilder();
		return result;
	}
	private static String generateInsertQuery(String jsonString) {
		boolean isFirst = true;
		JSONObject jsonObject = new JSONObject(jsonString);
		StringBuilder columns = new StringBuilder(" (");
		StringBuilder values = new StringBuilder(") VALUES (");
		for (String key : jsonObject.keySet()) {
			//String columnValue = jsonObject.optString(key);
			if (!isFirst) {
				columns.append(", ");
				values.append(", ");
			} else {
				isFirst = false;
			}
			columns.append(key);
			columns.append("?");
			//values.append("'").append(columnValue.replace("'", "''")).append("'"); // Échapper les apostrophes
		}
		if (columns.length() > 0 && values.length() > 0) {
			//todo:
		}
		sqlBuilder.append(columns);
		sqlBuilder.append(values);
		sqlBuilder.append(")");
		return buildAndClear();
	}
    //</editor-fold>
	//</editor-fold>
    //END//////////////////////////////////////////////////[static]/////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="INSTANCE">
    //START_______________________________________________[instance]__________________________________________________//
    //<editor-fold defaultstate="expanded" desc="SINGLETON">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="CONSTRUCTEURS">
	private Call() {}
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Attributs PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Methodes PUBLIC">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Attributs PRIVATE">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Methodes PRIVATE">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="ENCAPSULATION">
    //<editor-fold defaultstate="expanded" desc="Getters">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Setters">
    //</editor-fold>
	//</editor-fold>
    //END/////////////////////////////////////////////////[instance]////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="OVERRIDE">
	//START_______________________________________________[override]__________________________________________________//
	//END/////////////////////////////////////////////////[override]////////////////////////////////////////////////////
	//</editor-fold>
}