package sparadrap.utils;
/**
 * [Log] - class
 * @author Mathaus
 */
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public final class Log {

	// Nom de la classe statique pour centraliser les logs
	private static final Logger LOGGER = Logger.getLogger(Log.class.getName());
	public static String ILLEGAL_STATE = "Illegal state can't duplicalte singleton";

	static {
		try {
			// Configuration initiale
			LOGGER.setUseParentHandlers(false); // Évite la duplication de logs

			// Console Handler
			ConsoleHandler consoleHandler = new ConsoleHandler();
			consoleHandler.setLevel(Level.INFO); // Niveau minimum des logs pour la console
			consoleHandler.setFormatter(new SimpleFormatter()); // Formatteur simple
			LOGGER.addHandler(consoleHandler);

			// File Handler (écriture dans un fichier)
			FileHandler fileHandler = new FileHandler("app.log", true); // true pour append
			fileHandler.setLevel(Level.WARNING); // Tous les niveaux enregistrés dans le fichier
			fileHandler.setFormatter(new SimpleFormatter());
			LOGGER.addHandler(fileHandler);

			// Niveau global des logs
			LOGGER.setLevel(Level.ALL);

		} catch (Exception e) {
			// En cas d'échec de configuration
			LOGGER.log(Level.SEVERE, "Failed to initialize logger handlers", e);
		}
	}

	// Constructeur privé pour empêcher l'instanciation
	private Log() {
		throw new UnsupportedOperationException("Utility class");
	}

	// Méthode publique pour obtenir le logger
	public static Logger getLogger() {
		return LOGGER;
	}

	// Méthodes utilitaires pour simplifier l'usage
	public static void info(String message) {
		LOGGER.info(message);
	}

	public static void warning(String message) {
		LOGGER.warning(message);
	}

	public static void error(String message, Throwable throwable) {
		LOGGER.log(Level.SEVERE, message, throwable);
	}

	public static void debug(String message) {
		LOGGER.fine(message);
	}
}