package sparadrap.services;
import sparadrap.SparadrapDAO;
import sparadrap.enums.SparadrapTable;
import sparadrap.models.*;
import sparadrap.utils.Call;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
/**
 * [SparadrapDELETE] - class
 * @author Mathaus
 */
public class SparadrapDELETE {
	//<editor-fold defaultstate="expanded" desc="STATIC">
	//START________________________________________________[static]___________________________________________________//
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Proprietes PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Fonctions PUBLIC">
	public static void supprimerAchat(Achat achat) {
	//	supprimer(SparadrapTable.ACHAT, achat.getId());
	}
	public static void supprimerClient(Client client) {
		supprimer(SparadrapTable.CLIENT, client.getId());
	}
	public static void supprimerMedecin(Medecin medecin) {
		supprimer(SparadrapTable.MEDECIN, medecin.getId());
	}
	public static void supprimerMedicament(Medicament medicament) {
		supprimer(SparadrapTable.MEDICAMENT, medicament.getId());
	}
	public static void supprimerMutuelle(Mutuelle mutuelle) {
		supprimer(SparadrapTable.MUTUELLE, mutuelle.getId());
	}
	public static void supprimerOrdonance(Ordonance ordonance) {
		supprimer(SparadrapTable.ORDONANCE, ordonance.getId());
	}
	public static void supprimerSpecialite(Specialite specialite) {
		supprimer(SparadrapTable.SPECIALITE, specialite.getId());
	}
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Proprietes PRIVATE">
	private static SparadrapDAO dao = SparadrapDAO.getInstance();
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Fonctions PRIVATE">
	private static void supprimer(SparadrapTable table, int id) {
		Connection connection = dao.getConnection();
		if (connection != null) {
			try {
				PreparedStatement preparedStatement = connection.prepareStatement(Call.getDeleteStatement(table));
				preparedStatement.setInt(1, id);
				preparedStatement.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
    //</editor-fold>
	//</editor-fold>
    //END//////////////////////////////////////////////////[static]/////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="INSTANCE">
    //START_______________________________________________[instance]__________________________________________________//
    //<editor-fold defaultstate="expanded" desc="SINGLETON">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="CONSTRUCTEURS">
	private SparadrapDELETE() {}
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Attributs PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Methodes PUBLIC">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Attributs PRIVATE">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Methodes PRIVATE">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="ENCAPSULATION">
    //<editor-fold defaultstate="expanded" desc="Getters">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Setters">
    //</editor-fold>
	//</editor-fold>
    //END/////////////////////////////////////////////////[instance]////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="OVERRIDE">
	//START_______________________________________________[override]__________________________________________________//
	//END/////////////////////////////////////////////////[override]////////////////////////////////////////////////////
	//</editor-fold>
}