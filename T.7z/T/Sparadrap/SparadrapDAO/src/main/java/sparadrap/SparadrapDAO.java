package sparadrap;
import sparadrap.utils.Log;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import static sparadrap.utils.Log.*;

/**
 * [sparadrap.SparadrapDAO] - class
 * @author Mathaus
 */
public class SparadrapDAO {
	//<editor-fold defaultstate="expanded" desc="STATIC">
	//START________________________________________________[static]___________________________________________________//
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Proprietes PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Fonctions PUBLIC">
	public static final SparadrapDAO getInstance() {
		return SingletonSparadrapDAO.INSTANCE;
	}
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Proprietes PRIVATE">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Fonctions PRIVATE">
    //</editor-fold>
	//</editor-fold>
    //END//////////////////////////////////////////////////[static]/////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="INSTANCE">
    //START_______________________________________________[instance]__________________________________________________//
    //<editor-fold defaultstate="expanded" desc="SINGLETON">
	private static final class SingletonSparadrapDAO {
		private static final SparadrapDAO INSTANCE = new SparadrapDAO();
	}
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="CONSTRUCTEURS">
	private SparadrapDAO() {
		if (SingletonSparadrapDAO.INSTANCE != null) {
			Log.error(ILLEGAL_STATE, new IllegalStateException());
		}
		this.configureInstance();
	}
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Attributs PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Methodes PUBLIC">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Attributs PRIVATE">
	private Properties properties;
	private String dbSettings = "db.properties";
	private Connection connection = null;
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Methodes PRIVATE">
	private void configureInstance() {
		this.properties = new Properties();
		try (InputStream input = getClass().getClassLoader().getResourceAsStream(this.dbSettings)) {
			if (input == null) {
				throw new IllegalArgumentException("Fichier introuvable : " + this.dbSettings);
			}
			this.properties.load(input);
		} catch (IOException e) {
			throw new RuntimeException("Erreur lors du chargement du fichier properties", e);
		}
	}
	private void initConnection() {
		if (this.connection == null) {
			try {
				this.connection = DriverManager.getConnection(
						this.properties.getProperty("jdbc.url"),
						this.properties.getProperty("jdbc.login"),
						this.properties.getProperty("jdbc.password")
				);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="ENCAPSULATION">
    //<editor-fold defaultstate="expanded" desc="Getters">
	public final Connection getConnection() {
		this.initConnection();
		return this.connection;
	}
	public final void closeConnection() {
		if (this.connection != null) {
			try {
				this.connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		this.connection = null;
	}
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Setters">
    //</editor-fold>
	//</editor-fold>
    //END/////////////////////////////////////////////////[instance]////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="OVERRIDE">
	//START_______________________________________________[override]__________________________________________________//
	//END/////////////////////////////////////////////////[override]////////////////////////////////////////////////////
	//</editor-fold>
}