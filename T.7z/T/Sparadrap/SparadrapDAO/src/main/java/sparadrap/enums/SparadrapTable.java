package sparadrap.enums;
public enum SparadrapTable {
    ACHAT,
    ACHETER_MEDICAMENTS,
    CLIENT,
    COORDONNEE,
    EXERCER_SPECIALITES,
    LISTER_MEDECINS,
    LISTER_MEDICAMENTS,
    MEDECIN,
    MEDICAMENT,
    MUTUELLE,
    ORDONANCE,
    PERSONNE,
    SPECIALITE
}