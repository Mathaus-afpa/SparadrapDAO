package sparadrap.services;
import org.apache.commons.lang3.tuple.Pair;
import org.json.JSONObject;
import sparadrap.SparadrapDAO;
import sparadrap.enums.SparadrapTable;
import sparadrap.models.*;
import sparadrap.utils.Call;

import java.sql.*;
import java.util.ArrayList;
import java.util.Map;

/**
 * [SparadrapCREATE] - class
 * @author Mathaus
 */
public class SparadrapCREATE {
	//<editor-fold defaultstate="expanded" desc="STATIC">
//START________________________________________________[static]___________________________________________________//
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
	//<editor-fold defaultstate="expanded" desc="Proprietes PUBLIC">
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Fonctions PUBLIC">
	public static void creerAchat(Achat achat) throws Exception {
		creer(SparadrapTable.ACHAT, achat.buildJSON());
	}
	public static void creerClient(Client client) throws Exception {
		creer(SparadrapTable.CLIENT, client.buildJSON());
	}
	public static void creerCoordonnee(Coordonnee coordonnee) throws Exception {
		creer(SparadrapTable.COORDONNEE, coordonnee.buildJSON());
	}
	public static void creerPersonne(Personne personne) throws Exception {
		creer(SparadrapTable.PERSONNE, personne.buildJSON());
	}
	public static void creerMedecin(Medecin medecin) throws Exception {
		//ifpersonn
		creer(SparadrapTable.MEDECIN, medecin.buildJSON());
	}
	public static void creerMedicament(Medicament medicament) throws Exception {
		creer(SparadrapTable.MEDICAMENT, medicament.buildJSON());
	}
	public static void creerMutuelle(Mutuelle mutuelle) throws Exception {
		creer(SparadrapTable.MUTUELLE, mutuelle.buildJSON());
	}
	public static void creerOrdonance(Ordonance ordonance) throws Exception {
		creer(SparadrapTable.ORDONANCE, ordonance.buildJSON());
	}
	public static void creerSpecialite(Specialite specialite) throws Exception {
		 creer(SparadrapTable.SPECIALITE, specialite.buildJSON());
	}

	//</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
	//<editor-fold defaultstate="expanded" desc="Proprietes PRIVATE">
	private static SparadrapDAO dao = SparadrapDAO.getInstance();
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Fonctions PRIVATE">
	private static Integer creer(SparadrapTable table, Pair<String, Map<String, Object>> map) throws Exception {
		Connection connection = dao.getConnection();
		Pair<String, Map<String, Object>> pair = map;
		Integer lastInsertId = null;
		if (connection != null) {
			try {
				StringBuilder columns = new StringBuilder(" (");
				StringBuilder st = new StringBuilder(") VALUES (");
				ArrayList<String> values = new ArrayList<>();
				boolean isFirst = true;
				for ( Map.Entry<String, Object> entry : pair.getValue().entrySet() ) {
					if (!isFirst) {
						columns.append(", ");
						st.append(", ");
					} else {
						isFirst = false;
					}
					columns.append(entry.getKey());
					st.append("?");
					values.add(entry.getValue().toString());
				}
				st.append(")");
				PreparedStatement statement = connection.prepareStatement(Call.getInsertStatement(table, columns, st), Statement.RETURN_GENERATED_KEYS);
				for (int i = 1; i <= values.size(); i++) {
					statement.setString(i, values.get(i - 1));
				}
				System.out.println(statement.toString());
				statement.executeUpdate();
				try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
					if (generatedKeys.next()) {
						lastInsertId = generatedKeys.getInt(1);

					} else {
						System.out.println("Aucun ID généré !");
					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return lastInsertId;
	}
	//</editor-fold>
	//</editor-fold>
	//END//////////////////////////////////////////////////[static]/////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="INSTANCE">
    //START_______________________________________________[instance]__________________________________________________//
    //<editor-fold defaultstate="expanded" desc="SINGLETON">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="CONSTRUCTEURS">
	private SparadrapCREATE() {}
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Attributs PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Methodes PUBLIC">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Attributs PRIVATE">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Methodes PRIVATE">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="ENCAPSULATION">
    //<editor-fold defaultstate="expanded" desc="Getters">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Setters">
    //</editor-fold>
	//</editor-fold>
    //END/////////////////////////////////////////////////[instance]////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="OVERRIDE">
	//START_______________________________________________[override]__________________________________________________//
	//END/////////////////////////////////////////////////[override]////////////////////////////////////////////////////
	//</editor-fold>
}