package sparadrap.services;
import sparadrap.SparadrapDAO;
import sparadrap.enums.SparadrapTable;
import sparadrap.utils.Call;
import universaljson.UniversalJSON;
import universaljson.enums.UniversalSQL;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * [SparadrapJSON] - class
 * @author Mathaus
 */
public class SparadrapJSON {
	//<editor-fold defaultstate="expanded" desc="STATIC">
//START________________________________________________[static]___________________________________________________//
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
	//<editor-fold defaultstate="expanded" desc="Proprietes PUBLIC">
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Fonctions PUBLIC">
	public static void collecterAchat() {
		collecter(SparadrapTable.ACHAT);
	}
	public static void collecterClient() {
		collecter(SparadrapTable.CLIENT);
	}
	public static void collecterMedecin() {
		collecter(SparadrapTable.MEDECIN);
	}
	public static void collecterMedicament() {
		collecter(SparadrapTable.MEDICAMENT);
	}
	public static void collecterMutuelle() {
		collecter(SparadrapTable.MUTUELLE);
	}
	public static void collecterOrdonance() {
		collecter(SparadrapTable.ORDONANCE);
	}
	public static void collecterSpecialite() {
		collecter(SparadrapTable.SPECIALITE);
	}
	public static List<UniversalJSON> getAllRows(SparadrapTable table) {
		return datasets.get(table);
	}
	public static UniversalJSON getRowById(SparadrapTable table, int id) {
		return getAllRows(table).stream()
				.filter(row -> (int) row.getValue("IDSPECIALITE") == id)
				.findFirst()
				.orElse(null);
	}
	//</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
	//<editor-fold defaultstate="expanded" desc="Proprietes PRIVATE">
	private static SparadrapDAO dao = SparadrapDAO.getInstance();
	private static Map<SparadrapTable, List<UniversalJSON>> datasets = new HashMap<>();
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Fonctions PRIVATE">
	private static void collecter(SparadrapTable table) {
		Connection connection = dao.getConnection();
		if (connection != null) {
			try {
				PreparedStatement preparedStatement = connection.prepareStatement(Call.getSelectStatement(table));
				ResultSet resultSet = preparedStatement.executeQuery();
				datasets.put(table, SparadrapJSON.readResultSet(resultSet));
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	private static List<UniversalJSON> readResultSet(ResultSet resultSet) throws SQLException {
		List<UniversalJSON> rows = new ArrayList<>();
		ResultSetMetaData metaData = resultSet.getMetaData();
		int columnCount = metaData.getColumnCount();
		while (resultSet.next()) {
			UniversalJSON universalJSON = new UniversalJSON();
			for (int i = 1; i <= columnCount; i++) {
				String columnName = metaData.getColumnName(i);
				String value = resultSet.getString(i);
				UniversalSQL columnType = UniversalSQL.valueOf(metaData.getColumnTypeName(i));
				if (columnType != null && value != null) universalJSON.putKey(columnName, value, columnType);
				else System.out.println("TODO ??");
			}
			rows.add(universalJSON);
		}
		return rows;
	}
	//</editor-fold>
	//</editor-fold>
	//END//////////////////////////////////////////////////[static]/////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="INSTANCE">
    //START_______________________________________________[instance]__________________________________________________//
    //<editor-fold defaultstate="expanded" desc="SINGLETON">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="CONSTRUCTEURS">
	private SparadrapJSON() {}
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Attributs PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Methodes PUBLIC">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Attributs PRIVATE">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Methodes PRIVATE">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="ENCAPSULATION">
    //<editor-fold defaultstate="expanded" desc="Getters">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Setters">
    //</editor-fold>
	//</editor-fold>
    //END/////////////////////////////////////////////////[instance]////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="OVERRIDE">
	//START_______________________________________________[override]__________________________________________________//
	//END/////////////////////////////////////////////////[override]////////////////////////////////////////////////////
	//</editor-fold>
}