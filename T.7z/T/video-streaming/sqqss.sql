/*==============================================================*/
/* TABLE : COORDONNEE                                           */
/*==============================================================*/
-- Insertion des coordonnées des personnes (téléphone, email, adresse, etc.)
INSERT INTO COORDONNEE (TELEPHONE, EMAIL, CODEPOSTAL, ADRESSE) VALUES
('0612345678', 'jean.dupont@email.com', '75001', '10 Rue de Paris, 75001 Paris'),							-- Jean Dupont
('0789123456', 'marie.martin@email.com', '69002', '25 Rue Victor Hugo, 69002 Lyon'),						-- Marie Martin
('0698765432', 'pierre.lefevre@email.com', '13003', '15 Avenue des Alpes, 13003 Marseille'),				-- Pierre Lefevre
('0147589632', 'contact@mutuellesanteplus.com', '75008', '35 Boulevard de la République, 75008 Paris'),		-- Mutuelle Sante Plus
('0156728394', 'info@medimut.fr', '69003', '7 Rue des Frères Lumière, 69003 Lyon'),							-- Medimut
('0165938472', 'support@santemieux.com', '31000', '9 Rue des Roses, 31000 Toulouse'),						-- Sante Mieux
('0145789632', 'michel.bernard@medecin.com', '75010', '12 Rue de la Santé, 75010 Paris'),					-- Michel Bernard
('0168729354', 'sophie.leclerc@docteur.com', '69001', '3 Boulevard de la Liberté, 69001 Lyon'),				-- Sophie Leclerc
('0176548290', 'jacques.dubois@cabinetmed.com', '13004', '40 Rue de la République, 13004 Marseille'),		-- Jacques Dubois
('0187654321', 'marc.dupont@medecin.com', '75005', '15 Rue de la Paix, 75005 Paris'),						-- Marc Dupont
('0198765432', 'emilie.lemoine@medecin.com', '69004', '8 Rue de l\'Hôpital, 69004 Lyon'),					-- Emilie Lemoine
('0174321856', 'paul.martin@docteur.com', '13005', '22 Avenue du Prado, 13005 Marseille'),					-- Paul Martin
('0169458712', 'lucas.renaud@medecin.com', '75006', '10 Rue des Champs-Élysées, 75006 Paris');				-- Lucas Renaud
/*==============================================================*/
/* TABLE : MUTUELLE                                             */
/*==============================================================*/
-- Insertion des données des mutuelles
INSERT INTO MUTUELLE (IDCOORDONNEE, NOM, TAUXREMBOURSEMENT) VALUES
(4, 'Mutuelle Santé Plus', 75.00),
(5, 'MediMut', 85.00),
(6, 'SantéMieux', 80.00);
/*==============================================================*/
/* TABLE : PERSONNE                                             */
/*==============================================================*/
-- Insertion des données des personnes (médecins, clients, etc.)
INSERT INTO PERSONNE (IDCOORDONNEE, NOM, PRENOM) VALUES
(1, 'Dupont', 'Jean'),		-- Jean Dupont
(2, 'Martin', 'Marie'),		-- Marie Martin
(3, 'Lefevre', 'Pierre'),	-- Pierre Lefevre
(7, 'Bernard', 'Michel'),	-- Michel Bernard
(8, 'Leclerc', 'Sophie'),	-- Sophie Leclerc
(9, 'Dubois', 'Jacques'),	-- Emilie Lemoine
(10, 'Dupont', 'Marc'),		-- Marc Dupont
(11, 'Lemoine', 'Emilie'),	-- Emilie Lemoine
(12, 'Martin', 'Paul'),		-- Paul Martin
(13, 'Renaud', 'Lucas');	-- Lucas Renaud
/*==============================================================*/
/* TABLE : CLIENT                                               */
/*==============================================================*/
-- Insertion des clients et de leurs mutuelles (s'il y a lieu)
INSERT INTO CLIENT (IDPERSONNE, IDMUTUELLE, DATEDENAISSANCE, NUMEROSECURITESOCIALE) 
VALUES (1, NULL, '1980-05-15', '18005751234567890'),	-- Jean Dupont
       (2, 1, '1992-08-22', '29208692345678901'),		-- Marie Martin
       (3, 2, '1985-12-30', '18512133456789012'),		-- Pierre Lefevre
       (4, NULL, '1975-03-10', '17503134567890123');	-- Michel Bernard
/*==============================================================*/
/* TABLE : MEDECIN                                              */
/*==============================================================*/
-- Insertion des médecins avec leurs informations d'agrément
INSERT INTO MEDECIN (IDPERSONNE, AGREEMENT) 
VALUES (4, 123456),		-- Michel Bernard
       (5, 789012),		-- Sophie Leclerc
       (6, 345678),		-- Emilie Lemoine
	   (7, 987654),		-- Marc Dupont
	   (8, 654321),		-- Emilie Lemoine
	   (9, 112233),		-- Paul Martin
	   (10, 998877);	-- Lucas Renaud
/*==============================================================*/
/* TABLE : MEDICAMENT                                           */
/*==============================================================*/
-- Insertion des médicaments
INSERT INTO MEDICAMENT (DATEMISEENSERVICE, PRIX, LIBELLE, STOCK) VALUES
('2020-05-15', 12.50, 'Paracétamol', 200),
('2021-03-22', 35.00, 'Ibuprofène', 150),
('2022-06-10', 45.00, 'Amoxicilline', 120),
('2023-01-09', 10.75, 'Aspirine', 250),
('2021-11-15', 55.00, 'Atorvastatine', 100),
('2022-09-25', 60.30, 'Oméprazole', 180),
('2023-07-18', 80.00, 'Insuline', 80),
('2020-04-01', 20.00, 'Loratadine', 300),
('2022-08-03', 25.60, 'Clopidogrel', 90),
('2023-02-14', 15.40, 'Médrol', 50),
('2021-10-30', 50.00, 'Statines', 110),
('2020-12-12', 18.90, 'Bromazépam', 130),
('2022-07-20', 12.40, 'Fluconazole', 200),
('2023-05-12', 30.00, 'Levothyroxine', 60),
('2021-02-02', 12.00, 'Ranitidine', 220),
('2023-03-29', 40.00, 'Tensopril', 95),
('2020-09-10', 5.50, 'Vitamine D3', 500),
('2021-08-05', 75.00, 'Doxycycline', 75);
/*==============================================================*/
/* TABLE : ORDONANCE                                            */
/*==============================================================*/
-- Insertion des ordonnances (relier les ordonnances aux médecins et clients)
INSERT INTO ORDONANCE (IDMEDECIN, IDCLIENT, DATEPRESCRIPTION) 
VALUES (1, 1, '2024-01-15'),
       (2, 2, '2024-02-20'),
       (3, 3, '2024-03-05'),
       (1, 1, '2024-04-10'),
       (3, 2, '2024-05-25');
/*==============================================================*/
/* TABLE : ACHAT                                                */
/*==============================================================*/
-- Insertion des achats pour chaque ordonnance (avec des prescriptions)
INSERT INTO ACHAT (IDORDONANCE, IDCLIENT, DATEACHAT, NUMEROFACTURE) 
VALUES (1, 1, '2024-01-15 10:00:00', 100001),
       (2, 2, '2024-02-20 11:15:00', 100002),
       (3, 3, '2024-03-05 14:00:00', 100003),
       (4, 4, '2024-04-10 09:30:00', 100004),
       (5, 1, '2024-05-25 16:45:00', 100005),
       (NULL, 2, '2024-06-01 12:30:00', 100006),
       (NULL, 1, '2024-06-02 13:30:00', 100007),
       (NULL, 3, '2024-06-03 15:00:00', 100008),
       (NULL, 4, '2024-06-04 17:10:00', 100009),
       (NULL, 2, '2024-06-05 18:20:00', 100010),
       (NULL, 3, '2024-06-06 19:00:00', 100011),
       (NULL, 1, '2024-06-07 09:00:00', 100012),
       (NULL, 2, '2024-06-08 10:00:00', 100013),
       (NULL, 3, '2024-06-09 11:00:00', 100014),
       (NULL, 4, '2024-06-10 12:30:00', 100015),
       (NULL, 1, '2024-06-11 14:00:00', 100016),
       (NULL, 2, '2024-06-12 15:00:00', 100017),
       (NULL, 1, '2024-06-13 16:00:00', 100018),
	   (NULL, 2, '2024-06-14 17:00:00', 100019),
	   (NULL, 3, '2024-06-15 18:30:00', 100020);
/*==============================================================*/
/* TABLE : SPECIALITE                                           */
/*==============================================================*/
-- Insertion des spécialités médicales
INSERT INTO SPECIALITE (LIBELLE) VALUES
('Généraliste'),
('Cardiologie'),
('Dermatologie'),
('Pédiatrie'),
('Neurologie'),
('Gastroentérologie'),
('Ophtalmologie'),
('Orthopédie'),
('Rhumatologie'),
('Endocrinologie'),
('Psychiatrie'),
('Chirurgie générale'),
('Médecine interne'),
('Gynécologie'),
('Anesthésie-réanimation'),
('Radiologie'),
('Pneumologie'),
('Urologie'),
('Chirurgie cardiaque'),
('Néphrologie'),
('Médecine du travail');
/*==============================================================*/
/* TABLE : ACHETER_MEDICAMENTS                                  */
/*==============================================================*/
-- Achat 1 (ordonnance 1, client 1, médicament 1, 2 unités)
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (1, 1, 2);  -- Paracétamol, Quantité 2
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (1, 3, 1);  -- Ibuprofène, Quantité 1
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (1, 7, 5);  -- Insuline, Quantité 5
-- Achat 2 (ordonnance 2, client 2, médicament 2, 3 unités)
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (2, 2, 3);  -- Amoxicilline, Quantité 3
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (2, 5, 1);  -- Atorvastatine, Quantité 1
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (2, 9, 2);  -- Clopidogrel, Quantité 2
-- Achat 3 (ordonnance 3, client 3, médicament 4, 1 unité)
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (3, 4, 1);  -- Aspirine, Quantité 1
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (3, 8, 4);  -- Loratadine, Quantité 4
-- Achat 4 (ordonnance 4, client 5, médicament 6, 3 unités)
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (4, 6, 3);  -- Oméprazole, Quantité 3
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (4, 10, 2);  -- Statines, Quantité 2
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (4, 12, 5);  -- Bromazépam, Quantité 5
-- Achat 5 (ordonnance 5, client 6, médicament 2, 1 unité)
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (5, 2, 1);  -- Amoxicilline, Quantité 1
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (5, 4, 3);  -- Aspirine, Quantité 3
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (5, 18, 2);  -- Vitamine D3, Quantité 2
-- Achat 6 (sans ordonnance, client 2)
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (6, 1, 1);  -- Paracétamol, Quantité 1
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (6, 4, 3);  -- Aspirine, Quantité 3
-- Achat 7 (sans ordonnance, client 1)
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (7, 7, 5);  -- Insuline, Quantité 5
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (7, 12, 2);  -- Fluconazole, Quantité 2
-- Achat 8 (sans ordonnance, client 3)
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (8, 9, 1);  -- Clopidogrel, Quantité 1
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (8, 5, 1);  -- Atorvastatine, Quantité 1
-- Achat 9 (sans ordonnance, client 4)
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (9, 10, 3);  -- Statines, Quantité 3
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (9, 7, 2);  -- Insuline, Quantité 2
-- Achat 10 (sans ordonnance, client 5)
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (10, 2, 4);  -- Amoxicilline, Quantité 4
INSERT INTO ACHETER_MEDICAMENTS (IDACHAT, IDMEDICAMENT, QUANTITE) VALUES (10, 4, 2);  -- Aspirine, Quantité 2
/*==============================================================*/
/* TABLE : EXERCER_SPECIALITES                                  */
/*==============================================================*/
INSERT INTO EXERCER_SPECIALITES (IDMEDECIN, IDSPECIALITE) 
VALUES 
(1, (SELECT IDSPECIALITE FROM SPECIALITE WHERE LIBELLE = 'Cardiologie')),
(1, (SELECT IDSPECIALITE FROM SPECIALITE WHERE LIBELLE = 'Pneumologie')),
(2, (SELECT IDSPECIALITE FROM SPECIALITE WHERE LIBELLE = 'Dermatologie')),
(2, (SELECT IDSPECIALITE FROM SPECIALITE WHERE LIBELLE = 'Gynécologie')),
(2, (SELECT IDSPECIALITE FROM SPECIALITE WHERE LIBELLE = 'Généraliste')),
(3, (SELECT IDSPECIALITE FROM SPECIALITE WHERE LIBELLE = 'Neurologie')),
(3, (SELECT IDSPECIALITE FROM SPECIALITE WHERE LIBELLE = 'Psychiatrie')),
(3, (SELECT IDSPECIALITE FROM SPECIALITE WHERE LIBELLE = 'Généraliste')),
(4, 1), -- Généraliste
(5, 1), -- Généraliste
(6, 1), -- Généraliste
(7, 1); -- Généraliste
/*==============================================================*/
/* TABLE : LISTER_MEDICAMENTS                                   */
/*==============================================================*/
-- Pour l'ordonnance 1 (Dr. Michel Bernard, Client 1, 15 Jan 2024)
INSERT INTO LISTER_MEDICAMENTS (IDMEDICAMENT, IDORDONANCE, QUANTITE) VALUES (1, 1, 2);  -- Médicament 1, Quantité 2
INSERT INTO LISTER_MEDICAMENTS (IDMEDICAMENT, IDORDONANCE, QUANTITE) VALUES (3, 1, 1);  -- Médicament 3, Quantité 1
INSERT INTO LISTER_MEDICAMENTS (IDMEDICAMENT, IDORDONANCE, QUANTITE) VALUES (7, 1, 5);  -- Médicament 7, Quantité 5
-- Pour l'ordonnance 2 (Dr. Sophie Leclerc, Client 2, 20 Février 2024)
INSERT INTO LISTER_MEDICAMENTS (IDMEDICAMENT, IDORDONANCE, QUANTITE) VALUES (2, 2, 3);  -- Médicament 2, Quantité 3
INSERT INTO LISTER_MEDICAMENTS (IDMEDICAMENT, IDORDONANCE, QUANTITE) VALUES (5, 2, 1);  -- Médicament 5, Quantité 1
INSERT INTO LISTER_MEDICAMENTS (IDMEDICAMENT, IDORDONANCE, QUANTITE) VALUES (9, 2, 2);  -- Médicament 9, Quantité 2
-- Pour l'ordonnance 3 (Dr. Jacques Dubois, Client 3, 5 Mars 2024)
INSERT INTO LISTER_MEDICAMENTS (IDMEDICAMENT, IDORDONANCE, QUANTITE) VALUES (4, 3, 1);  -- Médicament 4, Quantité 1
INSERT INTO LISTER_MEDICAMENTS (IDMEDICAMENT, IDORDONANCE, QUANTITE) VALUES (8, 3, 4);  -- Médicament 8, Quantité 4
-- Pour l'ordonnance 4 (Dr. Michel Bernard, Client 1, 10 Avril 2024)
INSERT INTO LISTER_MEDICAMENTS (IDMEDICAMENT, IDORDONANCE, QUANTITE) VALUES (6, 4, 3);  -- Médicament 6, Quantité 3
INSERT INTO LISTER_MEDICAMENTS (IDMEDICAMENT, IDORDONANCE, QUANTITE) VALUES (10, 4, 2);  -- Médicament 10, Quantité 2
INSERT INTO LISTER_MEDICAMENTS (IDMEDICAMENT, IDORDONANCE, QUANTITE) VALUES (12, 4, 5);  -- Médicament 12, Quantité 5
-- Pour l'ordonnance 5 (Dr. Jacques Dubois, Client 2, 25 Mai 2024)
INSERT INTO LISTER_MEDICAMENTS (IDMEDICAMENT, IDORDONANCE, QUANTITE) VALUES (2, 5, 1);  -- Médicament 2, Quantité 1
INSERT INTO LISTER_MEDICAMENTS (IDMEDICAMENT, IDORDONANCE, QUANTITE) VALUES (4, 5, 3);  -- Médicament 4, Quantité 3
INSERT INTO LISTER_MEDICAMENTS (IDMEDICAMENT, IDORDONANCE, QUANTITE) VALUES (18, 5, 2);  -- Médicament 18, Quantité 
/*==============================================================*/
/* TABLE : LISTER_MEDECINS                                      */
/*==============================================================*/
INSERT INTO LISTER_MEDECINS (IDCLIENT, IDMEDECIN) VALUES (1, 1); -- Jean Dupont et Dr. Michel Bernard
INSERT INTO LISTER_MEDECINS (IDCLIENT, IDMEDECIN) VALUES (1, 2); -- Jean Dupont et Dr. Marc Dupont
INSERT INTO LISTER_MEDECINS (IDCLIENT, IDMEDECIN) VALUES (1, 3); -- Jean Dupont et Dr. Lucas Renaud
INSERT INTO LISTER_MEDECINS (IDCLIENT, IDMEDECIN) VALUES (2, 2); -- -- Marie Martin et Dr. Sophie Leclerc
INSERT INTO LISTER_MEDECINS (IDCLIENT, IDMEDECIN) VALUES (2, 3); -- -- Marie Martin et Dr. Jacques Dubois
INSERT INTO LISTER_MEDECINS (IDCLIENT, IDMEDECIN) VALUES (3, 1); -- -- Pierre Lefevre et Dr. Michel Bernard
INSERT INTO LISTER_MEDECINS (IDCLIENT, IDMEDECIN) VALUES (3, 2); -- -- Pierre Lefevre et Dr. Emilie Lemoine
INSERT INTO LISTER_MEDECINS (IDCLIENT, IDMEDECIN) VALUES (3, 3); -- -- Pierre Lefevre et Dr. Paul Martin
INSERT INTO LISTER_MEDECINS (IDCLIENT, IDMEDECIN) VALUES (4, 2); -- Michel Bernard et Dr. Sophie Leclerc
INSERT INTO LISTER_MEDECINS (IDCLIENT, IDMEDECIN) VALUES (4, 1); -- Michel Bernard et Dr. Emilie Lemoine
INSERT INTO LISTER_MEDECINS (IDCLIENT, IDMEDECIN) VALUES (4, 3); -- Michel Bernard et Dr. Lucas Renaud