/*==============================================================*/
/* NOM DU SGBD : MYSQL 5.0                                      */
/* DATE DE CRÉATION : 06/11/2024 10:47:20                       */
/*==============================================================*/
DROP DATABASE IF EXISTS SPARADRAP;
CREATE DATABASE SPARADRAP;
USE SPARADRAP;
/*==============================================================*/
/* TABLE : ACHAT                                                */
/*==============================================================*/
CREATE TABLE ACHAT
(
   IDACHAT              INT NOT NULL AUTO_INCREMENT,
   IDORDONANCE          INT,
   IDCLIENT             INT,
   DATEACHAT            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
   NUMEROFACTURE        INT NOT NULL UNIQUE, -- Calculé
   PRIMARY KEY (IDACHAT)
);
/*==============================================================*/
/* TABLE : ACHETER_MEDICAMENTS                                  */
/*==============================================================*/
CREATE TABLE ACHETER_MEDICAMENTS
(
   IDACHAT              INT NOT NULL,
   IDMEDICAMENT         INT NOT NULL,
   QUANTITE             INT NOT NULL,
   PRIMARY KEY (IDACHAT, IDMEDICAMENT)
);
/*==============================================================*/
/* TABLE : CLIENT                                               */
/*==============================================================*/
CREATE TABLE CLIENT
(
   IDCLIENT             INT NOT NULL AUTO_INCREMENT,
   IDPERSONNE           INT NOT NULL,
   IDMUTUELLE           INT,
   DATEDENAISSANCE      DATE,
   NUMEROSECURITESOCIALE VARCHAR(20) UNIQUE,
   PRIMARY KEY (IDCLIENT)
);
/*==============================================================*/
/* TABLE : COORDONNEE                                           */
/*==============================================================*/
CREATE TABLE COORDONNEE
(
   IDCOORDONNEE         INT NOT NULL AUTO_INCREMENT,
   TELEPHONE            VARCHAR(10) UNIQUE,
   EMAIL                VARCHAR(50),
   CODEPOSTAL           VARCHAR(5),
   ADRESSE              VARCHAR(100),
   PRIMARY KEY (IDCOORDONNEE)
);
/*==============================================================*/
/* TABLE : EXERCER_SPECIALITES                                  */
/*==============================================================*/
CREATE TABLE EXERCER_SPECIALITES
(
   IDMEDECIN            INT NOT NULL,
   IDSPECIALITE         INT NOT NULL,
   PRIMARY KEY (IDMEDECIN, IDSPECIALITE)
);
/*==============================================================*/
/* TABLE : LISTER_MEDICAMENTS                                   */
/*==============================================================*/
CREATE TABLE LISTER_MEDICAMENTS
(
   IDMEDICAMENT         INT NOT NULL,
   IDORDONANCE          INT NOT NULL,
   QUANTITE             INT NOT NULL,
   PRIMARY KEY (IDMEDICAMENT, IDORDONANCE)
);
/*==============================================================*/
/* TABLE : LISTER_MEDECINS                                      */
/*==============================================================*/
CREATE TABLE LISTER_MEDECINS
(
   IDCLIENT             INT NOT NULL,
   IDMEDECIN            INT NOT NULL,
   PRIMARY KEY (IDCLIENT, IDMEDECIN)
);
/*==============================================================*/
/* TABLE : MEDECIN                                              */
/*==============================================================*/
CREATE TABLE MEDECIN
(
   IDMEDECIN            INT NOT NULL AUTO_INCREMENT,
   IDPERSONNE           INT NOT NULL,
   AGREEMENT            INT NOT NULL UNIQUE,
   PRIMARY KEY (IDMEDECIN)
);
/*==============================================================*/
/* TABLE : MEDICAMENT                                           */
/*==============================================================*/
CREATE TABLE MEDICAMENT
(
   IDMEDICAMENT         INT NOT NULL AUTO_INCREMENT,
   DATEMISEENSERVICE    DATE,
   PRIX                 FLOAT,
   LIBELLE              VARCHAR(25) NOT NULL UNIQUE,
   STOCK                INT,
   PRIMARY KEY (IDMEDICAMENT)
);
/*==============================================================*/
/* TABLE : MUTUELLE                                             */
/*==============================================================*/
CREATE TABLE MUTUELLE
(
   IDMUTUELLE           INT NOT NULL AUTO_INCREMENT,
   IDCOORDONNEE         INT,
   NOM                  VARCHAR(25) NOT NULL,
   TAUXREMBOURSEMENT    FLOAT,
   PRIMARY KEY (IDMUTUELLE)
);
/*==============================================================*/
/* TABLE : ORDONANCE                                            */
/*==============================================================*/
CREATE TABLE ORDONANCE
(
   IDORDONANCE          INT NOT NULL AUTO_INCREMENT,
   IDMEDECIN            INT,
   IDCLIENT             INT,
   DATEPRESCRIPTION     DATE,
   PRIMARY KEY (IDORDONANCE)
);
/*==============================================================*/
/* TABLE : PERSONNE                                             */
/*==============================================================*/
CREATE TABLE PERSONNE
(
   IDPERSONNE           INT NOT NULL AUTO_INCREMENT,
   IDCOORDONNEE         INT,
   NOM                  VARCHAR(25) NOT NULL,
   PRENOM               VARCHAR(25) NOT NULL,
   PRIMARY KEY (IDPERSONNE)
);
/*==============================================================*/
/* TABLE : SPECIALITE                                           */
/*==============================================================*/
CREATE TABLE SPECIALITE
(
   IDSPECIALITE         INT NOT NULL AUTO_INCREMENT,
   LIBELLE              VARCHAR(25) NOT NULL UNIQUE,
   PRIMARY KEY (IDSPECIALITE)
);

/*==============================================================*/
/* CONTRAINTES : CLES ETRANGERES                                */
/*==============================================================*/

-- Contraintes de clé étrangère pour la table ACHAT
ALTER TABLE ACHAT 
    ADD CONSTRAINT FK_ACHAT_EFFECTUER_CLIENT FOREIGN KEY (IDCLIENT)
    REFERENCES CLIENT (IDCLIENT) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE ACHAT 
    ADD CONSTRAINT FK_ACHAT_UTILISER_ORDONANC FOREIGN KEY (IDORDONANCE)
    REFERENCES ORDONANCE (IDORDONANCE) ON DELETE SET NULL ON UPDATE CASCADE;

-- Contraintes de clé étrangère pour la table ACHETER_MEDICAMENTS
ALTER TABLE ACHETER_MEDICAMENTS 
    ADD CONSTRAINT FK_CONCERNE_ACHETER_MEDICAMENTS_ACHAT FOREIGN KEY (IDACHAT)
    REFERENCES ACHAT (IDACHAT) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE ACHETER_MEDICAMENTS 
    ADD CONSTRAINT FK_CONCERNE_ACHETER_MEDICAMENTS_MEDICAME FOREIGN KEY (IDMEDICAMENT)
    REFERENCES MEDICAMENT (IDMEDICAMENT) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Contraintes de clé étrangère pour la table CLIENT
ALTER TABLE CLIENT 
    ADD CONSTRAINT FK_CLIENT_CONTRACTE_MUTUELLE FOREIGN KEY (IDMUTUELLE)
    REFERENCES MUTUELLE (IDMUTUELLE) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE CLIENT 
    ADD CONSTRAINT FK_CLIENT_DEVENIR_PERSONNE FOREIGN KEY (IDPERSONNE)
    REFERENCES PERSONNE (IDPERSONNE) ON DELETE CASCADE ON UPDATE CASCADE;

-- Contraintes de clé étrangère pour la table EXERCER_SPECIALITES
ALTER TABLE EXERCER_SPECIALITES 
    ADD CONSTRAINT FK_EXERCER_SPECIALITES_EXERCER_SPECIALITES_MEDECIN FOREIGN KEY (IDMEDECIN)
    REFERENCES MEDECIN (IDMEDECIN) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE EXERCER_SPECIALITES 
    ADD CONSTRAINT FK_EXERCER_SPECIALITES_EXERCER_SPECIALITES2_SPECIALI FOREIGN KEY (IDSPECIALITE)
    REFERENCES SPECIALITE (IDSPECIALITE) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Contraintes de clé étrangère pour la table LISTER_MEDECINS
ALTER TABLE LISTER_MEDECINS 
    ADD CONSTRAINT FK_LISTER_MEDECINS_LISTER_MEDECINS_CLIENT FOREIGN KEY (IDCLIENT)
    REFERENCES CLIENT (IDCLIENT) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE LISTER_MEDECINS 
    ADD CONSTRAINT FK_LISTER_MEDECINS_LISTER_MEDECINS2_MEDECIN FOREIGN KEY (IDMEDECIN)
    REFERENCES MEDECIN (IDMEDECIN) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Contraintes de clé étrangère pour la table LISTER_MEDICAMENTS
ALTER TABLE LISTER_MEDICAMENTS 
    ADD CONSTRAINT FK_LISTER_MEDICAMENTS_LISTER_MEDICAMENTS_MEDICAME FOREIGN KEY (IDMEDICAMENT)
    REFERENCES MEDICAMENT (IDMEDICAMENT) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE LISTER_MEDICAMENTS 
    ADD CONSTRAINT FK_LISTER_MEDICAMENTS_LISTER_MEDICAMENTS2_ORDONANC FOREIGN KEY (IDORDONANCE)
    REFERENCES ORDONANCE (IDORDONANCE) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Contraintes de clé étrangère pour la table MEDECIN
ALTER TABLE MEDECIN 
    ADD CONSTRAINT FK_MEDECIN_ETRE_PERSONNE FOREIGN KEY (IDPERSONNE)
    REFERENCES PERSONNE (IDPERSONNE) ON DELETE CASCADE ON UPDATE CASCADE;

-- Contraintes de clé étrangère pour la table MUTUELLE
ALTER TABLE MUTUELLE 
    ADD CONSTRAINT FK_MUTUELLE_COORDONNEE FOREIGN KEY (IDCOORDONNEE)
    REFERENCES COORDONNEE (IDCOORDONNEE) ON DELETE SET NULL ON UPDATE CASCADE;

-- Contraintes de clé étrangère pour la table ORDONANCE
ALTER TABLE ORDONANCE 
    ADD CONSTRAINT FK_ORDONANC_OBTENIR_CLIENT FOREIGN KEY (IDCLIENT)
    REFERENCES CLIENT (IDCLIENT) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE ORDONANCE 
    ADD CONSTRAINT FK_ORDONANC_PRESCRIRE_MEDECIN FOREIGN KEY (IDMEDECIN)
    REFERENCES MEDECIN (IDMEDECIN) ON DELETE SET NULL ON UPDATE CASCADE;

-- Contraintes de clé étrangère pour la table PERSONNE
ALTER TABLE PERSONNE 
    ADD CONSTRAINT FK_PERSONNE_COORDONNEE FOREIGN KEY (IDCOORDONNEE)
    REFERENCES COORDONNEE (IDCOORDONNEE) ON DELETE SET NULL ON UPDATE CASCADE;