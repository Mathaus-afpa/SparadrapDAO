const express = require('express');
const bodyParser = require('body-parser');
const db = require('./db');
const { transcodeVideo } = require('./transcoder');
const path = require('path');
const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/public', express.static('public'));
app.use('/hls', express.static('hls'));

// Route principale
app.get('/', (req, res) => {
    db.query('SELECT * FROM videos', (err, rows) => {
        if (err) {
            throw err;
        }
        res.render('index', { videos: rows });
    });
});

// Route pour traiter la vidéo
app.post('/process/:id', (req, res) => {
    const videoId = req.params.id;
    
    // Mettre à jour l'état dans la base de données
    db.query(`UPDATE videos SET status = ? WHERE id = ?`, ['processing', videoId], (err) => {
        if (err) {
            console.error(err.message);
            return res.status(500).send('Erreur lors de la mise à jour de l’état.');
        };
        
        // Récupérer les informations de la vidéo
        db.query(`SELECT * FROM videos WHERE id = ?`, [videoId], (err, results) => {
            if (err) {
                console.error(err.message);
                return res.status(500).send('Erreur lors de la récupération des informations de la vidéo.');
            }

            const video = results[0];
            // Transcoder la vidéo
            transcodeVideo(video);
            res.redirect('/');
        });
    });
});

// Route pour lire la vidéo
app.get('/watch/:id', (req, res) => {
    const videoId = req.params.id;
    db.query(`SELECT * FROM videos WHERE id = ?`, [videoId], (err, results) => {
        if (err) {
            console.error(err.message);
            return res.status(500).send('Erreur lors de la récupération de la vidéo.');
        }
        const video = results[0];
        res.render('watch', { video });
    });
});

// Démarrer le serveur
app.listen(PORT, () => {
    console.log(`Serveur en cours d'exécution sur http://localhost:${PORT}`);
});
