const { exec } = require('child_process');
const db = require('./db');

function transcodeVideo(video) {
    const outputDir = './hls/';
    const outputPlaylist = `${outputDir}${video.id}.m3u8`;
    const inputFilePath = video.path;

const command = `ffmpeg -i "${inputFilePath}" \
    -codec:v libx264 -preset veryfast -crf 23 \
    -codec:a aac -b:a 128k \
    -hls_time 10 \
    -hls_list_size 0 \
    -hls_segment_filename "${outputDir}${video.id}_%03d.ts" \
    "${outputPlaylist}"`;


    exec(command, (error, stdout, stderr) => {
        if (error) {
            console.error(`Erreur de transcoding: ${error.message}`);
            return;
        }

        // Mettre à jour l'état dans la base de données
        db.query(`UPDATE videos SET status = ? WHERE id = ?`, ['ready', video.id], (err) => {
            if (err) {
                console.error(err.message);
            }
            console.log(`Vidéo ${video.title} transcodée avec succès.`);
        });
    });
}

module.exports = { transcodeVideo };