const mysql = require('mysql');

// Configurer la connexion à la base de données MySQL
const db = mysql.createConnection({
    host: 'localhost',  // Remplacez par l'adresse de votre serveur MySQL
    user: 'root',  // Remplacez par votre nom d'utilisateur MySQL
    password: 'root',  // Remplacez par votre mot de passe MySQL
    database: 'hlsvid'  // Remplacez par le nom de votre base de données
});

// Établir la connexion
db.connect(err => {
    if (err) {
        throw err;
    }
    console.log('Connecté à la base de données MySQL');
});

// Créer la table si elle n'existe pas
db.query(`CREATE TABLE IF NOT EXISTS videos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    path VARCHAR(255) NOT NULL,
    status ENUM('pending', 'processing', 'ready') DEFAULT 'pending'
)`, (err) => {
    if (err) throw err;
});

module.exports = db;