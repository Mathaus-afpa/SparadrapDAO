/*const express = require('express');
const { PassThrough } = require('stream');
const path = require('path');

const app = express();
const PORT = 8000;

// Servir le fichier HTML statique depuis le répertoire racine ou 'public'
app.use(express.static(path.join(__dirname, 'public')));

// Route pour recevoir le flux vidéo
app.get('/stream', (req, res) => {
    res.writeHead(200, {
        'Content-Type': 'video/webm', // Change ceci selon le type de vidéo
        'Transfer-Encoding': 'chunked'
    });

    const pass = new PassThrough();
    req.pipe(pass).pipe(res);
});

// Route pour servir index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`Serveur en cours d'exécution sur http://localhost:${PORT}`);
});

const express = require('express');
const http = require('http');
const { PassThrough } = require('stream');
const app = express();
const PORT = 8000;

// URL du flux audio Icecast
const ICECAST_URL = 'http://localhost:8000/stream';

// Route pour le streaming audio
app.get('/stream', (req, res) => {
    res.writeHead(200, {
        'Content-Type': 'video/webm', // Change ceci selon le type de vidéo
        'Transfer-Encoding': 'chunked'
    });

    const pass = new PassThrough();
    req.pipe(pass).pipe(res);
});

// Servir une page HTML avec un lecteur audio
app.get('/', (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html lang="fr">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Lecture Flux Audio</title>
        </head>
        <body>
            <h1>Écoute du Flux Audio</h1>
            <video controls autoplay>
                <source src="/stream" type="video/mp4">
                Votre navigateur ne supporte pas l'écoute audio en streaming.
            </video>
        </body>
        </html>
    `);
});

app.listen(PORT, () => {
    console.log(`Serveur en cours d'exécution sur http://localhost:${PORT}`);
});
*/
/*
const express = require('express');
const { spawn } = require('child_process');

const app = express();
const PORT = 8000;

// Route pour diffuser le flux vidéo
app.get('/stream', (req, res) => {
    res.writeHead(200, {
        'Content-Type': 'video/webm',
        'Transfer-Encoding': 'chunked',
    });
/*
    // Lance ffmpeg pour générer un flux/*
    const ffmpeg = spawn('ffmpeg', [
        '-re', '-i', 'test.mp4', // Remplacez par la source de votre choix
        '-f', 'webm', // Format de sortie du flux
        '-c:v', 'libvpx', // Codec vidéo pour WebM
        '-b:v', '1M', // Bitrate vidéo
        '-c:a', 'libvorbis', // Codec audio
        '-f', 'webm', // Sortie en format WebM
        'pipe:1' // Sortie vers stdout
    ]);

const ffmpeg = spawn('ffmpeg', [
    '-re', '-i', 'test.mp4', // Remplacez par la source de votre choix
    '-vf', 'scale=640:-1', // Réduit la résolution vidéo à 640px de large
    '-r', '24', // Limite le framerate à 24fps
    '-c:v', 'libvpx', // Codec vidéo pour WebM
    '-b:v', '500k', // Réduit le bitrate vidéo à 500kbps
    '-c:a', 'libvorbis', // Codec audio
    '-b:a', '128k', // Réduit le bitrate audio à 128kbps
    '-f', 'webm', // Sortie en format WebM
    'pipe:1' // Sortie vers stdout
]);
    ffmpeg.stdout.pipe(res);

    ffmpeg.stderr.on('data', (data) => {
        console.error(`Erreur ffmpeg: ${data}`);
    });

    req.on('close', () => {
        ffmpeg.kill('SIGTERM'); // Arrête ffmpeg si le client ferme la connexion
    });
});

// Route pour servir la page HTML avec lecteur vidéo
app.get('/', (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html lang="fr">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Lecture Flux Vidéo</title>
        </head>
        <body>
            <h1>Lecture du Flux Vidéo en Direct</h1>
            <video controls autoplay>
                <source src="/stream" type="video/webm">
                Votre navigateur ne supporte pas la lecture vidéo en streaming.
            </video>
        </body>
        </html>
    `);
});

app.listen(PORT, () => {
    console.log(`Serveur en cours d'exécution sur http://localhost:${PORT}`);
});
*/
const express = require('express');
const cors = require('cors');
const request = require('request');

const app = express();
const port = 8000;

app.use(cors());

// Endpoint pour servir le flux existant
app.get('/live', (req, res) => {
    const streamUrl = 'http://localhost:8000/live'; // URL du flux existant

    // Pipe le flux existant vers la réponse
    request.get(streamUrl)
        .on('response', (response) => {
            res.setHeader('Content-Type', 'video/mp2t'); // Type MIME pour MPEG-TS
            response.pipe(res);
        })
        .on('error', (err) => {
            console.error('Erreur lors de la récupération du flux :', err);
            res.sendStatus(500);
        });
});

app.listen(port, () => {
    console.log(`Serveur en cours d'exécution sur http://localhost:${port}/live`);
});
