const express = require('express');
const http = require('http');

const app = express();
const PORT = 8000; // Port du serveur

// Route pour servir le flux audio
app.get('/stream', (req, res) => {
    // Définit les en-têtes de la réponse
    res.writeHead(200, {
        'Content-Type': 'video/webm', // Type de l'audio
        'Transfer-Encoding': 'chunked',
        'Cache-Control': 'no-cache',
    });

    // Ici, nous ne gérons pas la connexion au flux ; c'est FFmpeg qui s'en occupe.
    // Nous restons simplement à l'écoute pour le flux envoyé par FFmpeg.
});

// Servir la page HTML avec le lecteur audio
app.get('/', (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html lang="fr">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Lecture du Flux Audio</title>
        </head>
        <body>
            <h1>Écoute du Flux Audio</h1>
            <video controls autoplay>
                <source src="http://localhost:${PORT}/stream" type="video/webm">
                Votre navigateur ne supporte pas la lecture de l'audio.
            </video>
        </body>
        </html>
    `);
});

// Démarre le serveur
app.listen(PORT, () => {
    console.log(`Serveur en cours d'exécution sur http://localhost:${PORT}`);
});
