package sparadrap.enums;
public enum SparadrapTable {
    ACHAT,
    ACHETER_MEDICAMENTS,
    CLIENT,
    EXERCER_SPECIALITES,
    LISTER_MEDECINS,
    LISTER_MEDICAMENTS,
    MEDECIN,
    MEDICAMENT,
    MUTUELLE,
    ORDONANCE,
    SPECIALITE
}