package sparadrap.services;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import sparadrap.SparadrapDAO;
import sparadrap.enums.SparadrapTable;
import sparadrap.models.*;
import sparadrap.utils.Call;
import universaljson.UniversalJSON;
import org.json.JSONObject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map.Entry;
/**
 * [SparadrapCREATE] - class
 * @author Mathaus
 */
public class SparadrapCREATE {
	//<editor-fold defaultstate="expanded" desc="STATIC">
//START________________________________________________[static]___________________________________________________//
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
	//<editor-fold defaultstate="expanded" desc="Proprietes PUBLIC">
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Fonctions PUBLIC">
	public static void creerAchat(Achat achat) {
		creer(SparadrapTable.ACHAT, achat.getId());
	}
	public static void creerClient(Client client) {
		creer(SparadrapTable.CLIENT, client.getId());
	}
	public static void creerMedecin(Medecin medecin) {
		creer(SparadrapTable.MEDECIN, medecin.getId());
	}
	public static void creerMedicament(Medicament medicament) {
		creer(SparadrapTable.MEDICAMENT, medicament.getId());
	}
	public static void creerMutuelle(Mutuelle mutuelle) {
		creer(SparadrapTable.MUTUELLE, mutuelle.getId());
	}
	public static void creerOrdonance(Ordonance ordonance) {
		creer(SparadrapTable.ORDONANCE, ordonance.getId());
	}
	public static void creerSpecialite(Specialite specialite) throws Exception {
		specialite.setLibelle("Coucou");
//		StringBuilder tablename = new StringBuilder("INSERT INTO specialite (");
//		StringBuilder value = new StringBuilder(" VALUES (");
//		int size = specialite.getFields().size();
//		int i = 0;
//		for (String key : specialite.getFields()) {
//			tablename.append(key);
//			value.append("?");
//			if (i < size - 1) {
//				tablename.append(", ");
//				value.append(", ");
//			} else {
//				tablename.append(")");
//				value.append(")");
//			}
//			i++;
//		}
		//creer(SparadrapTable.SPECIALITE, specialite.getId());
		System.out.println(generateInsertQuery("specialite", specialite.stringify()));
	}
	public static String generateInsertQuery(String tableName, String jsonString) throws Exception {
		// Convertir le JSON en un objet JsonNode (Jackson)
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode jsonNode = objectMapper.readTree(jsonString);

		// StringBuilder pour construire la requête SQL
		StringBuilder columns = new StringBuilder();
		StringBuilder values = new StringBuilder();

		// Itérer sur les clés et valeurs du JSON
		Iterator<Entry<String, JsonNode>> fields = jsonNode.fields();
		while (fields.hasNext()) {
			Entry<String, JsonNode> field = fields.next();
			String columnName = field.getKey();
			String columnValue = field.getValue().asText();

			// Ajouter le nom de la colonne et la valeur correspondante à la requête
			if (columns.length() > 0) {
				columns.append(", ");
				values.append(", ");
			}
			columns.append(columnName);
			values.append("'").append(columnValue).append("'");
		}

		// Construire la requête complète
		String query = "INSERT INTO " + tableName + " (" + columns + ") VALUES (" + values + ")";
		return query;
	}
	//</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
	//<editor-fold defaultstate="expanded" desc="Proprietes PRIVATE">
	private static SparadrapDAO dao = SparadrapDAO.getInstance();
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Fonctions PRIVATE">
	private static void creer(SparadrapTable table, int id) {
		Connection connection = dao.getConnection();
		if (connection != null) {
			try {
				PreparedStatement preparedStatement = connection.prepareStatement(Call.getDeleteStatement(table));
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	//</editor-fold>
	//</editor-fold>
	//END//////////////////////////////////////////////////[static]/////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="INSTANCE">
    //START_______________________________________________[instance]__________________________________________________//
    //<editor-fold defaultstate="expanded" desc="SINGLETON">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="CONSTRUCTEURS">
	private SparadrapCREATE() {}
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Attributs PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Methodes PUBLIC">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Attributs PRIVATE">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Methodes PRIVATE">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="ENCAPSULATION">
    //<editor-fold defaultstate="expanded" desc="Getters">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Setters">
    //</editor-fold>
	//</editor-fold>
    //END/////////////////////////////////////////////////[instance]////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="OVERRIDE">
	//START_______________________________________________[override]__________________________________________________//
	//END/////////////////////////////////////////////////[override]////////////////////////////////////////////////////
	//</editor-fold>
}