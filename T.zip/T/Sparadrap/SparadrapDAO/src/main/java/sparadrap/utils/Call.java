package sparadrap.utils;
import sparadrap.enums.SparadrapTable;

import javax.swing.*;
import java.awt.*;
/**
 * [Call] - class
 * @author Mathaus
 */
public class Call {
	//<editor-fold defaultstate="expanded" desc="STATIC">
	//START________________________________________________[static]___________________________________________________//
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Proprietes PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Fonctions PUBLIC">
	public static final String getDeleteStatement(SparadrapTable table) {
		clearStringBuilder();
		sqlBuilder.append("DELETE FROM ");
		sqlBuilder.append(table);
		sqlBuilder.append(" WHERE ID");
		sqlBuilder.append(table);
		sqlBuilder.append(" = ?");
		return sqlBuilder.toString();
	}
	public static final String getSelectStatement(SparadrapTable table) {
		switch (table) {
			case ACHAT: return "SELECT * FROM achat";
			case CLIENT: return "SELECT e.identite, e.nom, e.adresse, e.telephone, e.email, e.codePostal, p.idPersonne, p.prenom, c.idClient, c.dateDeNaissance, c.numeroSecuriteSociale, c.idMutuelle FROM entite e JOIN personne p ON e.identite = p.identite JOIN client c ON p.idPersonne = c.idPersonne";
			case MEDECIN: return "SELECT e.identite, e.nom, e.adresse, e.telephone, e.email, e.codePostal, p.idPersonne, p.prenom, m.idMedecin, m.agreement FROM entite e JOIN personne p ON e.identite = p.identite JOIN medecin m ON p.idPersonne = m.idPersonne";
			case MEDICAMENT: return "SELECT * FROM medicaments";
			case MUTUELLE: return "SELECT e.identite, e.nom, e.adresse, e.telephone, e.email, e.codePostal, m.idMutuelle, m.tauxRemboursement FROM entite e JOIN mutuelle m ON m.identite = e.identite";
			case ORDONANCE: return "SELECT * FROM ordonance";
			case SPECIALITE: return "SELECT * FROM specialite";
			//case BONBON: return "SELECT * FROM bonbon";
			default: return "SELECT * FROM "  + table;
		}
    }
	public static final String getInsertStatement(SparadrapTable table) {
		switch (table) {
			case ACHAT: return "INSERT INTO achat (idordonance, idclient, dateachat, prescription, numerofacture) VALUES (?, ?, ?, ?, ?)";
			case CLIENT: return "procedure";
			case MEDECIN: return "procedure";
			case MEDICAMENT: return "INSERT INTO medicament (datemiseenservice, prix, libelle, stock) VALUES (?, ?, ?, ?)";
			case MUTUELLE: return "INSERT INTO mutuelle (tauxremboursement) VALUES (?)";
			case ORDONANCE: return "INSERT INTO ordonance (idmedecin, idclient, dateprescription) VALUES (?, ?, ?)";
			case SPECIALITE: return "INSERT INTO specialite (libelle) VALUES (?)";
			//case BONBON: return "SELECT * FROM bonbon";
			default: return "SELECT * FROM "  + table;
		}
	}
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Proprietes PRIVATE">
	private static StringBuilder sqlBuilder = new StringBuilder();
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Fonctions PRIVATE">
	private static void clearStringBuilder() {
		sqlBuilder.delete(0, sqlBuilder.length());
		sqlBuilder.setLength(0);
	}
    //</editor-fold>
	//</editor-fold>
    //END//////////////////////////////////////////////////[static]/////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="INSTANCE">
    //START_______________________________________________[instance]__________________________________________________//
    //<editor-fold defaultstate="expanded" desc="SINGLETON">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="CONSTRUCTEURS">
	private Call() {}
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Attributs PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Methodes PUBLIC">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Attributs PRIVATE">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Methodes PRIVATE">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="ENCAPSULATION">
    //<editor-fold defaultstate="expanded" desc="Getters">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Setters">
    //</editor-fold>
	//</editor-fold>
    //END/////////////////////////////////////////////////[instance]////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="OVERRIDE">
	//START_______________________________________________[override]__________________________________________________//
	//END/////////////////////////////////////////////////[override]////////////////////////////////////////////////////
	//</editor-fold>
}