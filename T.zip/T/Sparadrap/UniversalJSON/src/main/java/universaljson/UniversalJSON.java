package universaljson;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.tuple.Pair;
import universaljson.enums.UniversalSQL;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
public class UniversalJSON
{
    //<editor-fold defaultstate="expanded" desc="STATIC">
    //START________________________________________________[static]___________________________________________________//
    //<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Proprietes PUBLIC">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Fonctions PUBLIC">
    //</editor-fold>
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Proprietes PRIVATE">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Fonctions PRIVATE">
    //</editor-fold>
    //</editor-fold>
    //END//////////////////////////////////////////////////[static]/////////////////////////////////////////////////////
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="INSTANCE">
    //START_______________________________________________[instance]__________________________________________________//
    //<editor-fold defaultstate="expanded" desc="SINGLETON">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="CONSTRUCTEURS">
    public UniversalJSON(List<Pair<String, UniversalSQL>> fields) {
        for (Pair<String, UniversalSQL> field : fields) {
            this.putKey(field.getLeft(), null, field.getRight());
        }
    }
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Attributs PUBLIC">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Methodes PUBLIC">
    public void changeKey(String key, String value) {
        this.values.put(key,  UniversalSQL.convert(this.datatypes.get(key), value));
    }
    public void putKey(String key, String value, UniversalSQL type) {
        if (ifNewKey(key)) {// value null ok ?
            this.values.put(key, UniversalSQL.convert(type, value));
            this.datatypes.put(key, type);
            this.keys.add(key);
        }
    }
    public String stringify() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return (stringOnly) ? objectMapper.writeValueAsString(this.formatValues())
                : objectMapper.writeValueAsString(this.clearNull());
    }
    //</editor-fold>
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Attributs PRIVATE">
    private Map<String, Object> values = new HashMap<>();
    private Map<String, UniversalSQL> datatypes = new HashMap<>();
    private Map<String, Pair<String, String>> checksums = new HashMap<>();

    public List<String> getKeys() {
        return keys.stream()
                .filter(key -> values.get(key) != null)  // Filtrer les clés pour lesquelles la valeur n'est pas nulle
                .collect(Collectors.toList());            // Collecter et retourner la liste filtrée
    }

    private List<String> keys = new ArrayList<>();
    private boolean stringOnly = false;
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Methodes PRIVATE">
    private boolean ifNewKey(String key) {
        return !this.values.containsKey(key) && !this.datatypes.containsKey(key) && !this.checksums.containsKey(key);
    }

    private Map<String, Object> clearNull() {
        return this.values.entrySet().stream()
                .filter(entry -> entry.getValue() != null)
                .collect(Collectors.toMap(
                        entry -> entry.getKey(),
                        entry -> entry.getValue()
                ));
    }
    private Map<String, String> formatValues() {
        return this.clearNull().entrySet().stream()
                .filter(entry -> entry.getValue().toString() != null)
                .collect(Collectors.toMap(
                        entry -> entry.getKey(),
                        entry -> entry.getValue().toString()
                ));
    }
    //</editor-fold>
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="ENCAPSULATION">
    //<editor-fold defaultstate="expanded" desc="Getters">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Setters">
    public void setStringOnly(boolean stringOnly) {
        this.stringOnly = stringOnly;
    }
    public Object getValue(String key) {
        System.out.println(this.values.get("IDSPECIALITE"));

        return this.values.get(key);
    }
    //</editor-fold>
    //</editor-fold>
    //END/////////////////////////////////////////////////[instance]////////////////////////////////////////////////////
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="OVERRIDE">
    //START_______________________________________________[override]__________________________________________________//
    //END/////////////////////////////////////////////////[override]////////////////////////////////////////////////////
    //</editor-fold>
}