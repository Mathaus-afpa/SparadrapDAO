import com.fasterxml.jackson.core.JsonProcessingException;
import sparadrap.enums.SparadrapTable;
import sparadrap.models.*;
import sparadrap.services.SparadrapCREATE;
import sparadrap.services.SparadrapJSON;
import universaljson.UniversalJSON;
public class SparadrapJava
{
    public static void main( String[] args ) throws Exception {
        SparadrapCREATE.creerSpecialite(new Specialite());
        //SparadrapJSON.collecterSpecialite();
        //Client client = new Client();
        //client.setNumeroSecuriteSociale("12414554");
        //System.out.println(client.stringify());
        //new UniversalDebugFrame<>(SparadrapJSON.getAllRows(SparadrapTable.SPECIALITE), Specialite.class);
    }
}